//
//  AppDelegate.h
//  TestFrameworkExample
//
//  Created by 耿葱 on 2025/6/12.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;
@end

